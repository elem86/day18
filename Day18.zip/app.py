import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

# Load the data
df = pd.read_csv("train.csv")

# Basic cleanup
df.columns = df.columns.str.lower().str.replace(" ", "_")

# Parse order_date robustly
df["order_date"] = pd.to_datetime(df["order_date"], dayfirst=True)
df["ship_date"] = pd.to_datetime(df["ship_date"], dayfirst=True)


st.title("📊 Superstore Dashboard")

# Sidebar filter
regions = df["region"].dropna().unique()
selected_region = st.selectbox("Choose a region:", options=sorted(regions))

# Filter the data
filtered_df = df[df["region"] == selected_region].copy()

# KPIs
st.subheader(f"📍 KPIs for {selected_region}")
total_sales = filtered_df["sales"].sum()
total_orders = filtered_df["order_id"].nunique()
st.metric("Total Sales", f"${total_sales:,.0f}")
st.metric("Total Orders", total_orders)

# Monthly sales chart
st.subheader("📈 Monthly Sales")
monthly_sales = (
    filtered_df.groupby(filtered_df["order_date"].dt.to_period("M"))["sales"]
    .sum()
    .reset_index()
)
monthly_sales["order_date"] = monthly_sales["order_date"].dt.to_timestamp()

fig, ax = plt.subplots()
sns.lineplot(data=monthly_sales, x="order_date", y="sales", ax=ax)
ax.yaxis.set_major_formatter(FuncFormatter(lambda x, _: f"${x:,.0f}"))
plt.xticks(rotation=45)
ax.set_ylabel("Sales")
ax.set_xlabel("Month")
ax.set_title("Monthly Sales Trend")
st.pyplot(fig)

# Show filtered data table with readable dates
filtered_df["order_date"] = filtered_df["order_date"].dt.strftime("%Y-%m-%d")
filtered_df["ship_date"] = filtered_df["ship_date"].dt.strftime("%Y-%m-%d")

st.subheader("🗃️ Filtered Data")
st.dataframe(filtered_df.head(50))
